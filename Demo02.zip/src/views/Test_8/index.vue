<template>
  <div>
   1
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>